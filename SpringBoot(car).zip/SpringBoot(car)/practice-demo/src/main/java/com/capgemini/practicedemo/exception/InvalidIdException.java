package com.capgemini.practicedemo.exception;

public class InvalidIdException extends RuntimeException{

}
