package com.capgemini.practicedemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.practicedemo.dto.CarDTO;
import com.capgemini.practicedemo.repository.CarDAO;

@Service
public class CarServiceImpl implements CarService {
	
	@Autowired
	private CarDAO carDaoRef;

	@Override
	public List<CarDTO> findAll() {
		
		return carDaoRef.findAll();
	}

	@Override
	public CarDTO findById(int id) {
		
		return carDaoRef.findById(id);
	}

	@Override
	public CarDTO create(CarDTO car) {
		
		return carDaoRef.create(car);
	}

	@Override
	public CarDTO update(CarDTO car) {
		
		return carDaoRef.update(car);
	} 

	@Override
	public CarDTO delete(int id) {
		
		return carDaoRef.delete(id);
	}
	

}
