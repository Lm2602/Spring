package com.capgemini.practicedemo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

import com.capgemini.practicedemo.dto.CarDTO;
import com.capgemini.practicedemo.repository.CarDAO;
import com.capgemini.practicedemo.service.CarService;


@RestController
@RequestMapping("/controller")
public class CarActionsControllerHelper {
	@Autowired
	private CarService serRef;

	@RequestMapping(method=RequestMethod.GET, value="car")
	public List<CarDTO> list()
	{    
		return serRef.findAll();
	}
	
	@RequestMapping(method=RequestMethod.POST, value="car")
	public CarDTO save(@RequestBody CarDTO car)
	{
		return serRef.create(car);
	}
	
	@RequestMapping(method=RequestMethod.GET, value="car/{id}")
	public CarDTO get(@PathVariable(name="id") int id)
	{
		return serRef.findById(id);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="car/{id}")
	public CarDTO update(@RequestBody CarDTO car,@PathVariable(name="id") int id)
	{
		return serRef.update(car);
	}

	@RequestMapping(method=RequestMethod.DELETE, value="car/{id}")
	public CarDTO delete(@PathVariable(name="id") int id)
	{
		return serRef.delete(id);
	}

}
