package com.capgemini.practicedemo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.practicedemo.dto.CarDTO;
import com.capgemini.practicedemo.exception.InvalidIdException;


@Repository
@Transactional
public class JPACarDAO implements CarDAO{
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public CarDTO create(CarDTO car) {
		System.out.println("putting wreck");
		entityManager.persist(car);
		
		return car;
	}
	
	/*@Override
	public CarDTO update(Long id, CarDTO wreck) {
		
		
	//	entityManager.merge(wreck);
		
	    s.setId(s.getId());
		s.setCondition(wreck.getCondition());
		s.setDepth(wreck.getDepth());
		s.setDescription(wreck.getDescription());
		s.setLatitude(wreck.getLatitude());
		s.setName(wreck.getName());
		entityManager.persist(s);
		return s;
	}*/

	@Override
	public List<CarDTO> findAll() {
		Query query = entityManager.createQuery(
				"select car from CarDTO car");
		
				return query.getResultList();
	}

	@Override
	public CarDTO findById(int id) {
		CarDTO c=entityManager.find(CarDTO.class, id);
		if(c==null)
			throw new InvalidIdException();
			return c;
	
	}

	@Override
	public CarDTO update(CarDTO car) {
		
		
		/*CarDTO s=(CarDTO)entityManager.find(CarDTO.class, id);
		s.setMake(car.getMake());
		s.setModel(car.getModel());
		s.setModelYear(car.getModelYear());*/
		return entityManager.merge(car);
	}

	@Override
	public CarDTO delete(int id) {
		CarDTO s=(CarDTO)entityManager.find(CarDTO.class, id);
		entityManager.remove(s);
		return s;
	}
	

}
