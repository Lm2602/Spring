package com.capgemini.practicedemo.exception;

public class InvalidNameExp extends RuntimeException{

}
