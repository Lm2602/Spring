package com.capgemini.product.dao;

import java.util.List;

import com.capgemini.product.ProductDTO;

public interface IProductRepo {

	
	public ProductDTO create(ProductDTO productdto);
	public ProductDTO update(int id,ProductDTO productdto);
	public ProductDTO delete(int id);
	public ProductDTO get(int id);
    public List<ProductDTO> findAll();
}
