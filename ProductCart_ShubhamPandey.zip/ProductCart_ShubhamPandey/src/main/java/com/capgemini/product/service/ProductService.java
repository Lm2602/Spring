package com.capgemini.product.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.product.ProductDTO;
import com.capgemini.product.ProductDTO;
@Service
public interface ProductService {

	public ProductDTO create(ProductDTO productdto);
	public ProductDTO update(int id,ProductDTO productdto);
	public ProductDTO delete(int id);
    public ProductDTO get(int id);
	public List<ProductDTO> findAll();
	
	
}
