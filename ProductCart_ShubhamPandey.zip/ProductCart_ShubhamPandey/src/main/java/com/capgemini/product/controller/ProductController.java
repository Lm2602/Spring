package com.capgemini.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.product.ProductDTO;
import com.capgemini.product.service.ProductService;

@RestController
@RequestMapping("/controller")
public class ProductController {

	@Autowired(required=true)
	private ProductService serRef;
	
	@RequestMapping(method=RequestMethod.POST,value="product")
	public ProductDTO create(@RequestBody ProductDTO productdto) {
		return serRef.create(productdto);
		}
	
	@RequestMapping(method=RequestMethod.PUT,value="/product/{id}")
	public ProductDTO update(@PathVariable int id,@RequestBody ProductDTO productdto) {
		return serRef.update(id, productdto);
		}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/product/{id}")
	public ProductDTO delete(@PathVariable int id) {
		return serRef.delete(id);
		}	
	
	@RequestMapping(method=RequestMethod.GET,value="/product/{id}")
	public ProductDTO get(@PathVariable int id) {
		return serRef.get(id);
		}
	
	@RequestMapping(method=RequestMethod.GET,value="product")
	public List<ProductDTO> findAll(){
		return serRef.findAll();
	}
	
}
