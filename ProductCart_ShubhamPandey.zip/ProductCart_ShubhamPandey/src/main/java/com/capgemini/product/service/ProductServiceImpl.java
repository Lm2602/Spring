package com.capgemini.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.product.ProductDTO;
import com.capgemini.product.dao.ProductRepoImpl;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired(required=true)
	ProductRepoImpl daoRef;
	public List<ProductDTO> findAll(){
		return daoRef.findAll() ;	
	}
	public ProductDTO create(ProductDTO productdto) {
		return daoRef.create(productdto);
	}
	public ProductDTO get(int id) {
		return daoRef.get(id);
	}
	public ProductDTO update(int id,ProductDTO productdto) {
		return daoRef.update(id, productdto);
		
	}
	public ProductDTO delete(int id) {
		return daoRef.delete(id);
		
	}
}
