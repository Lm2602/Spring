package com.capgemini.product.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.product.ProductDTO;

@Repository
@Transactional
public class ProductRepoImpl implements IProductRepo{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@Transactional
	public ProductDTO create(ProductDTO productdto) {
		 entityManager.persist(productdto);
		 return productdto;
	}

	
	@Override
	@Transactional
	public ProductDTO update( int id,ProductDTO productdto) {
		entityManager.merge(productdto);
		entityManager.flush();
		return productdto;
	}
	
	
	@Override
	@Transactional
	public ProductDTO delete(int id) {
	    /* entityManager.remove(id);*/
		ProductDTO product= entityManager.find(ProductDTO.class, id);
		entityManager.remove(product);
		entityManager.flush();
		return product;
		 
	}
	
	
	@Override
	@Transactional
	public ProductDTO get(int id) {
		ProductDTO productdto= entityManager.find(ProductDTO.class, id);
		return productdto;
	}

	

	@Override
	@Transactional
	public List<ProductDTO> findAll() {
		
		TypedQuery<ProductDTO> query=entityManager.createQuery("select prod from ProductDto prod ", ProductDTO.class);
						
					List<ProductDTO> list= query.getResultList();
					System.out.println("inside find all:"+list);
				return list;
		/*Query query= entityManager.createQuery(" select * from Product");
		return query.getResultList();*/
		
	}
	
	
}
